# weather.py

import requests

class WeatherModule:
    def __init__(self):
        self.api_key = "YOUR_WEATHER_API_KEY"

    def get_weather(self, location):
        # Get weather data from API
        url = f"http://api.weather.com/weather/{location}?api_key={self.api_key}"
        response = requests.get(url)
        return response.json()