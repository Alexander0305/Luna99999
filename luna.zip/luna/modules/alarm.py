# alarm.py

import datetime
import time

class AlarmModule:
    def __init__(self):
        self.alarm_time = datetime.datetime.now() + datetime.timedelta(minutes=10)

    def set_alarm(self, alarm_time):
        # Set alarm for a specific time
        self.alarm_time = alarm_time

    def check_alarm(self):
        # Check if it's time to trigger the alarm
        if datetime.datetime.now() >= self.alarm_time:
            # TO DO: Implement alarm trigger logic
            pass