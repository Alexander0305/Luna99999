# email.py

import smtplib
from email.mime.text import MIMEText

class EmailModule:
    def __init__(self):
        self.smtp_server = "smtp.gmail.com"
        self.smtp_port = 587
        self.username = "your_email@gmail.com"
        self.password = "your_password"

    def send_email(self, recipient, subject, message):
        # Send email using SMTP
        msg = MIMEText(message)
        msg['Subject'] = subject
        msg['From'] = self.username
        msg['To'] = recipient
        server = smtplib.SMTP(self.smtp_server, self.smtp_port)
        server.starttls()
        server.login(self.username, self.password)
        server.sendmail(self.username, recipient, msg.as_string())
        server.quit()